# Simulação CFD de um Árbol: Geração de Geometria e Malha com OpenFOAM

Este projeto apresenta a simulação de um objeto do tipo "árvore" em OpenFOAM, com foco no processo de criação da geometria, configuração do `snappyHexMesh` e visualização da malha resultante.

## ✏️ Criação da Geometria

Diferente de projetos que utilizam modelos STL prontos, a geometria desta árvore foi **criada manualmente a partir da combinação de formas básicas**:

- O **tronco** foi modelado como um **cilindro vertical**.
- A **copa da árvore** foi representada por um **cone fechado**.
- As duas partes foram **unidas e centralizadas usando ferramentas de manipulação geométrica** e transformações (como rotação, translação e escala) dentro do ambiente do projeto.

O modelo final foi exportado como um único arquivo `.stl` após diversas iterações e testes de qualidade da malha.

## 🧩 Geração da Malha

O processo de malhagem foi realizado com o `snappyHexMesh`, partindo de uma malha base gerada com `blockMesh`. Os principais passos foram:

1. Configuração de um `blockMeshDict` simples para definir o domínio de simulação.
2. Importação do STL da árvore em `constant/triSurface`.
3. Definição de refinamentos locais e regiões de captura no `snappyHexMeshDict`.
4. Geração e verificação da malha resultante em ParaView.

O projeto permitiu visualizar claramente a adaptação da malha ao contorno da árvore, além de compreender os desafios de meshing em geometrias complexas.

## 👤 Autor

Juan Blanco Silva  
Estudante de Engenharia | UFRJ 